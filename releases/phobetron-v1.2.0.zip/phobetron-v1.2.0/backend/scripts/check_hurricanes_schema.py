#!/usr/bin/env python3
"""
Check hurricanes table schema
"""

import os
from sqlalchemy import create_engine, text

def check_hurricanes_schema():
    database_url = os.getenv('DATABASE_URL')
    if not database_url:
        print("❌ DATABASE_URL not set")
        return

    engine = create_engine(database_url)

    try:
        with engine.connect() as conn:
            # Get hurricanes table schema
            result = conn.execute(text("""
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns
                WHERE table_name = 'hurricanes'
                ORDER BY ordinal_position;
            """))

            print("🔍 hurricanes table schema:")
            for row in result:
                nullable = "NULL" if row[2] == 'YES' else "NOT NULL"
                print(f"  - {row[0]}: {row[1]} {nullable}")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    check_hurricanes_schema()