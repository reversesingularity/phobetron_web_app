"""Core package initialization."""
