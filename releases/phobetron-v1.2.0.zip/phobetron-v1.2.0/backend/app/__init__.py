"""Celestial Signs Backend Application."""

__version__ = "0.1.0"
